import React  from 'react';

import './App.css';
import Header from './components/Header/Header';
import Head from './components/Head/Head';
import { Headb } from './components/Headb/Headb';

import Middle from './components/midddle/Middle';
import Footer from './components/Footer/Footer';
import Mid from './components/Mid/Mid';

function App() {
  return (
    <div>
  <Headb/>
  <Middle/>
  <Footer/>
  
   
    </div>
  );
}

export default App;
